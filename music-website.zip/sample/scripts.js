// Example of an audio player functionality enhancement (optional)
document.querySelector('audio').addEventListener('play', function() {
    alert('Enjoy the music!');
});

